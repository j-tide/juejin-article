# Agent 系统工程 01 配套实验

[阅读全文](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/01%EF%BD%9C%E6%A8%A1%E5%9E%8B%E4%B9%8B%E5%A4%96%EF%BC%8CHarness%20%E5%88%B0%E5%BA%95%E8%AF%A5%E8%B4%9F%E8%B4%A3%E4%BB%80%E4%B9%88%EF%BC%9F/README.md)。

本实验验证 Agent 运行时的执行边界与验收行为。所有模型提案由确定性的 `ReplayPolicy` 提供，证据是明确标注的本地教学资料；不调用在线模型、不联网、不执行外部发布。实验结果不能作为任何真实模型的能力或可靠性成绩。

## 运行

需要 Python 3.10 及以上，仅使用标准库。在本目录执行：

```bash
python3 harness_lab.py --output experiment-results
python3 -m unittest -v test_harness
```

前者执行 10 组预定义故障/正例场景，分别开启与关闭结构验收，生成 `results.json` 和 `traces.json`；后者执行 9 个独立的运行时不变量测试。

## 文件

- `harness_lab.py`：契约、状态、证据、动作执行、验收快照、预算限制，以及确定性实验。
- `test_harness.py`：快照绑定、反馈回传、空章节、预算、非法参数与动作检查。
- `experiment-results/results.json`：每个场景的状态、轮数与工具调用数量。
- `experiment-results/traces.json`：两组实验的逐步动作和验收事件。

## 契约与已知边界

`REVIEW_READY` 只表示结构和来源登记检查通过。校验器不判断自然语言主张是否成立，也不判断来源是否支持主张。实验专门保留一份“结构合格、结论夸大”的报告，明确复现这一盲点。

验收时读取一份不可变的字节快照；验收记录绑定报告、契约和证据内容的哈希。消费者应读取 `accepted_bytes`，而不是再次按可变草稿路径读取。哈希不是可信签名。

本章没有持久化运行状态，没有进程崩溃恢复、并发控制、真实模型适配器、真实检索服务或远程请求取消机制。决策轮数和工具次数上限不能替代请求超时。下一章将基于此版本实现持久状态与崩溃恢复。

关闭验收的对照组刻意接受模型的完成请求，是用于观察错误路径的实验开关，不能用于真实交付。

修订版补充：引用标记先完整提取再验证格式；新任务拒绝复用已有 draft.md 的目录。
