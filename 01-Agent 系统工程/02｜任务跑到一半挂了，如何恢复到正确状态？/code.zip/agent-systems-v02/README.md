# Agent 系统工程 v02

第 02 篇对应的累计代码快照，支持第 02—02 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 02 --output results/02.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/02%EF%BD%9C%E4%BB%BB%E5%8A%A1%E8%B7%91%E5%88%B0%E4%B8%80%E5%8D%8A%E6%8C%82%E4%BA%86%EF%BC%8C%E5%A6%82%E4%BD%95%E6%81%A2%E5%A4%8D%E5%88%B0%E6%AD%A3%E7%A1%AE%E7%8A%B6%E6%80%81%EF%BC%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
