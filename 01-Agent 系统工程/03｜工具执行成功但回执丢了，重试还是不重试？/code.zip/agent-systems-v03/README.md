# Agent 系统工程 v03

第 03 篇对应的累计代码快照，支持第 02—03 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 03 --output results/03.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/03%EF%BD%9C%E5%B7%A5%E5%85%B7%E6%89%A7%E8%A1%8C%E6%88%90%E5%8A%9F%E4%BD%86%E5%9B%9E%E6%89%A7%E4%B8%A2%E4%BA%86%EF%BC%8C%E9%87%8D%E8%AF%95%E8%BF%98%E6%98%AF%E4%B8%8D%E9%87%8D%E8%AF%95%EF%BC%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
