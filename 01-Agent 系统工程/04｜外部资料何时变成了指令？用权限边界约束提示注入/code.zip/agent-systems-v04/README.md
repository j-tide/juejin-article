# Agent 系统工程 v04

第 04 篇对应的累计代码快照，支持第 02—04 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 04 --output results/04.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/04%EF%BD%9C%E5%A4%96%E9%83%A8%E8%B5%84%E6%96%99%E4%BD%95%E6%97%B6%E5%8F%98%E6%88%90%E4%BA%86%E6%8C%87%E4%BB%A4%EF%BC%9F%E7%94%A8%E6%9D%83%E9%99%90%E8%BE%B9%E7%95%8C%E7%BA%A6%E6%9D%9F%E6%8F%90%E7%A4%BA%E6%B3%A8%E5%85%A5/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
