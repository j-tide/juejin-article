# Agent 系统工程 v05

第 05 篇对应的累计代码快照，支持第 02—05 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 05 --output results/05.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/05%EF%BD%9C%E4%B8%8A%E4%B8%8B%E6%96%87%E5%8E%8B%E7%BC%A9%E4%BB%A5%E5%90%8E%EF%BC%8C%E6%80%8E%E6%A0%B7%E7%9F%A5%E9%81%93%E5%85%B3%E9%94%AE%E4%BF%A1%E6%81%AF%E6%9C%89%E6%B2%A1%E6%9C%89%E4%B8%A2%EF%BC%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
