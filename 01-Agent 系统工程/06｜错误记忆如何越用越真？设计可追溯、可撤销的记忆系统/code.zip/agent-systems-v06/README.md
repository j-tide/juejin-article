# Agent 系统工程 v06

第 06 篇对应的累计代码快照，支持第 02—06 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 06 --output results/06.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/06%EF%BD%9C%E9%94%99%E8%AF%AF%E8%AE%B0%E5%BF%86%E5%A6%82%E4%BD%95%E8%B6%8A%E7%94%A8%E8%B6%8A%E7%9C%9F%EF%BC%9F%E8%AE%BE%E8%AE%A1%E5%8F%AF%E8%BF%BD%E6%BA%AF%E3%80%81%E5%8F%AF%E6%92%A4%E9%94%80%E7%9A%84%E8%AE%B0%E5%BF%86%E7%B3%BB%E7%BB%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
