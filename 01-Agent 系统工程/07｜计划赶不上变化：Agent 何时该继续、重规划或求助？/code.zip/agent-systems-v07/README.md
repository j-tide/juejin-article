# Agent 系统工程 v07

第 07 篇对应的累计代码快照，支持第 02—07 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 07 --output results/07.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/07%EF%BD%9C%E8%AE%A1%E5%88%92%E8%B5%B6%E4%B8%8D%E4%B8%8A%E5%8F%98%E5%8C%96%EF%BC%9AAgent%20%E4%BD%95%E6%97%B6%E8%AF%A5%E7%BB%A7%E7%BB%AD%E3%80%81%E9%87%8D%E8%A7%84%E5%88%92%E6%88%96%E6%B1%82%E5%8A%A9%EF%BC%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
