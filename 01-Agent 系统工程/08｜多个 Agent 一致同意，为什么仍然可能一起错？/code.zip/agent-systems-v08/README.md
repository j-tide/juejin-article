# Agent 系统工程 v08

第 08 篇对应的累计代码快照，支持第 02—08 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 08 --output results/08.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/08%EF%BD%9C%E5%A4%9A%E4%B8%AA%20Agent%20%E4%B8%80%E8%87%B4%E5%90%8C%E6%84%8F%EF%BC%8C%E4%B8%BA%E4%BB%80%E4%B9%88%E4%BB%8D%E7%84%B6%E5%8F%AF%E8%83%BD%E4%B8%80%E8%B5%B7%E9%94%99%EF%BC%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
