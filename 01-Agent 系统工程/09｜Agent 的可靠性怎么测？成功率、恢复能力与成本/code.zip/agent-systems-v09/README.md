# Agent 系统工程 v09

第 09 篇对应的累计代码快照，支持第 02—09 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 09 --output results/09.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/09%EF%BD%9CAgent%20%E7%9A%84%E5%8F%AF%E9%9D%A0%E6%80%A7%E6%80%8E%E4%B9%88%E6%B5%8B%EF%BC%9F%E6%88%90%E5%8A%9F%E7%8E%87%E3%80%81%E6%81%A2%E5%A4%8D%E8%83%BD%E5%8A%9B%E4%B8%8E%E6%88%90%E6%9C%AC/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。
