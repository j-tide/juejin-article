# Agent 系统工程 v10

第 10 篇对应的累计代码快照，支持第 02—10 篇实验。

Python 3.10+，标准库，无模型调用、无联网。在本目录运行：

```bash
python3 run.py 10 --output results/10.json
```

[对应文章](https://github.com/j-tide/juejin-article/blob/main/01-Agent%20%E7%B3%BB%E7%BB%9F%E5%B7%A5%E7%A8%8B/10%EF%BD%9C%E4%B8%80%E6%AC%A1%E9%95%BF%E4%BB%BB%E5%8A%A1%E5%A4%B1%E8%B4%A5%EF%BC%8C%E5%A6%82%E4%BD%95%E5%AE%9A%E4%BD%8D%E5%8E%9F%E5%9B%A0%E5%B9%B6%E9%AA%8C%E8%AF%81%E4%BF%AE%E5%A4%8D%EF%BC%9F/README.md)说明实验条件；`lab/` 是截至本章的模块，`results/` 是执行结果。各章适用范围和未实现部分见正文。

完整集成：`python3 integration.py`。
